//
//  IosTImeApp.swift
//  IosTIme
//
//  Created by Peter Ekler on 02/09/2024.
//

import SwiftUI

@main
struct IosTImeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
